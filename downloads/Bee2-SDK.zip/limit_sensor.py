import time

from DBDynamics import Bee

m = Bee('/dev/ttyUSB0')
mid = 0
m.setPowerOnPro(id=mid, limit_soft=0, limit_hard=1, limit_fast=1, open_loop=0)
m.setPositionMode(mid)
m.setAccTime(mid, 500)
m.setTargetVelocity(mid, 500)
for loop in range(0, 3):
    m.setTargetPosition(mid, 51200 * 20)
    m.waitTargetPositionReached(mid)

    m.setTargetPosition(mid, 51200 * 0)
    m.waitTargetPositionReached(mid)
m.stop()
