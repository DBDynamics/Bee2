import time

from DBDynamics import Bee
import random

m = Bee('/dev/ttyUSB0')
mid = 0
# m.setPowerOnLimit(mid, 0, 1, 0)
# m.setPowerOn(mid)
m.setPowerOnPro(id=mid, limit_soft=0, limit_hard=0, limit_fast=0, open_loop=0)
m.setPositionMode(mid)
m.setAccTime(mid, 200)
m.setTargetVelocity(mid, 10000)
for loop in range(0, 10):
    m.setTargetPosition(mid, 51200 * random.randint(1, 20))
    m.waitTargetPositionReached(mid)

    m.setTargetPosition(mid, 51200 * 0.01)
    m.waitTargetPositionReached(mid)
m.stop()
