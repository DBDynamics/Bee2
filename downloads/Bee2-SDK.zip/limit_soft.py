import time

from DBDynamics import Bee

m = Bee('/dev/ttyUSB0')
mid = 0
m.setLimitPositionP(mid, 51200*1)
m.setLimitPositionN(mid, 51200*-1)
m.setPowerOnPro(id=mid, limit_soft=1, limit_hard=0, limit_fast=0, open_loop=1)
# m.setPowerOn(mid)
m.setPositionMode(mid)
m.setAccTime(mid, 200)
m.setTargetVelocity(mid, 1000)
for loop in range(0, 3):
    m.setTargetPosition(mid, 51200 * 2)
    m.waitTargetPositionReached(mid)

    m.setTargetPosition(mid, 51200 * -10)
    m.waitTargetPositionReached(mid)
m.stop()
