import time

from DBDynamics import Bee

m = Bee('/dev/ttyUSB0')
mid = 0
# m.setAccTime(mid, 100)
# m.setOpModeEstopFast(mid)
m.setOpModeEstopProfile(mid)

m.stop()